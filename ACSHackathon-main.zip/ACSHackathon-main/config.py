WTF_CSRF_ENABLED = True
SECRET_KEY = 'a-very-secret-secret'
